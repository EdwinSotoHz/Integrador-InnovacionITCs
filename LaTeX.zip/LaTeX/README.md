# Archivo Template-manuscrito.tex

Este archivo contiene todo los detalles de como se debe de redactar el informe final del proyecto integrador de primer semestre. Los archivos **IEEEcsmag.cls**, **sfmath.sty** y **upmath.sty** sirven para renderizar la plantilla del archivo **Template-manuscrito.tex**.

La carpeta **latex-imagenes** contiene las 2 imagenes utilizadas por el archivo **Template-manuscrito.tex**. Se recomienda poner todas las imagenes que se van a utilizar para el reporte final dentro de esta carpeta.

El resultado de compilar el archivo **Template-manuscrito.tex** se puede apreciar en el archivo **Template-manuscrito.pdf**.
